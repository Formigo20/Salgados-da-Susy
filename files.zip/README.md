# Salgados da Susy

Website simples para o negócio "Salgados da Susy". Esta versão está preparada para ser publicada via GitHub Pages.

Visite a página (depois de ativar Pages):

https://Formigo20.github.io/salgados-da-susy/

O que está incluído:
- index.html — página principal
- assets/ — imagens e styles.css

Como editar:
1. Atualize o telefone em `index.html`.
2. Substitua `assets/logo.svg` e `assets/qr.svg` pelos ficheiros reais.
3. Faça commit e push para a branch `main`.

Ativar GitHub Pages:
- Vá a Settings → Pages → Branch → selecione `main` e `/ (root)` e guarde.

LICENCE: MIT